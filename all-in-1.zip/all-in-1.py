#ToolEasy Installer# Python2 
#Tools By MarMu
#Face Book - Technology By MarMu
#Do not modify this tool 
#love u all :)
################  Gone Gyi; What r u looking for  ############################################################################

b="\033[1m"
u="\033[4m" 
bl="\033[30m"
r="\033[31m"
g="\033[32m"
bu="\033[34m"
m="\033[35m"
c="\033[36m"
w="\033[37m"
ec="\033[0m"
blue="\033[1;34m"
p="\033[1;36m"
red="\033[1;31m"
tes="\033[1;97m"
k="\033[1;93m"
t="\033[1;91m"
gt="\033[1;92m"
a="\033[1;96m"

import os,sys,time

def marmu():
     os.system("clear")

def main():
    time.sleep(1)
    marmu()
    time.sleep(1)
    print ('\33[1;33m                           Do \33[31;1mYou \33[35;1mKnow \33[0;36mMarMu')
    time.sleep(1)
    marmu()
    print ('\033[1;32m')
    os.system ('figlet All-In-1')
    time.sleep(0.5)
    marmu()
    print ('\033[1;96m')
    os.system ('figlet All-In-1')
    time.sleep(0.5)
    marmu()
    print ('\033[1;33m')
    os.system ('figlet All-In-1')
    time.sleep(0.5)
    marmu()
    print ('\033[1;35m')
    os.system ('figlet All-In-1')
    print'\33[36;1m+\33[1;34m=====================================================\33[36;1m+'
    print'\33[36;1m+\33[1;34m====+++===+++++=====   \33[31;1m marmu  \33[1;34m  =====+++++===+++====\33[36;1m+'
    print'\33[36;1m+\33[1;34m=====================================================\33[36;1m+'

    print'\33[36;1m+     \33[32;1mAUTHOR    \33[31;1m=> \33[1;33mMarMu                              \33[36;1m+'
    print'\33[36;1m+     \33[32;1mFACEBOOK  \33[31;1m=> \33[1;33mTechonology By MarMu               \33[36;1m+'
    print'\33[36;1m+     \33[32;1mINSTAGRAM \33[31;1m=> \33[1;33mHtet Aung                          \33[36;1m+'
    print'\33[36;1m+     \33[32;1mGITHUB    \33[31;1m=> \33[1;33mhttps://github.com/MarMu-Myanmar   \33[36;1m+ '
    print'\33[36;1m+\33[1;34m=====================================================\33[36;1m+'
    print'\33[33;1m|  ....................  \33[37;1mM E N U \33[33;1m...................  |'     
    print'\33[36;1m+\33[1;34m=====================================================\33[36;1m+'

    print'\33[36;1m|     \33[33;1m{\33[37;1m1\33[32;1m} \33[36;1mFB Old Acc Auto Cracking                    \33[36;1m|'
    print'\33[36;1m|     \33[33;1m{\33[37;1m2\33[32;1m} \33[36;1mFB Mail Cracking                            \33[36;1m|'
    print'\33[36;1m|     \33[33;1m{\33[37;1m3\33[32;1m} \33[36;1mEasy Active Acc Auto Hacking                \33[36;1m|'
    print'\33[36;1m|     \33[33;1m{\33[37;1m4\33[32;1m} \33[36;1mAuto Crack [FB Login With Token]            \33[36;1m|'
    print'\33[36;1m|     \33[33;1m{\33[37;1m5\33[32;1m} \33[36;1mFB Acc Bruteforce Attacking                 \33[36;1m|'
    print'\33[36;1m|     \33[33;1m{\33[37;1m6\33[32;1m} \33[36;1mYour Name Logo & Termux Hacker Theme        \33[36;1m|'
    print'\33[36;1m|     \33[33;1m{\33[37;1m7\33[32;1m} \33[36;1mContact to MarMu [Author]                   \33[36;1m|'
    print'\33[36;1m|     \33[33;1m{\33[31;1m0\33[32;1m} \33[31;1mExit                                        \33[36;1m|'
    print'\33[36;1m+\33[1;34m=====================================================\33[36;1m+'
    print'\33[1;35m~ '
    print'\33[1;35m~ '
    gans = raw_input ('\033[1;32m==>>>\033[1;38m ')

#######################  Credit - BOT   ###############################
    if gans in ['1']:
        time.sleep(1)
        os.system('pkg install python2')
        os.system('pip2 install tqdm')
        os.system('pip2 install requests')
        os.system('pip2 install mechanize')
        os.system('rm -rf Sensei')
        os.system ('git clone https://github.com/BOT-033/Sensei')
        marmu()
	time.sleep(2)
	print'\33[1;33mlove \33[31;1myou \33[0;36mAll.......'
	marmu()
        os.system('cd Sensei;python2 main.py')
        os.system('rm -rf Sensei')
        
#######################  Credit - LoveHacker  #######################
    if gans in ['2']:
        time.sleep(1)
        os.system('rm -rf random')
        os.system('pkg update && pkg upgrade -y')
        os.system('pkg install python git')
        os.system('pip2 install futures')
        os.system('pip2 install requests bs4')
        os.system('git clone https://github.com/lovehacker404/random')
        marmu()
	time.sleep(2)
        print'\33[1;33mlove \33[31;1myou \33[0;36mAll.......'
	marmu()
        os.system('cd random')
        os.system('cd random;python2 lovehacker.py')
	os.system('rm -r random')
        sys.exit
        os.system('rm -rf random')
        
#########################  Credit - HunterBoy  #######################
    if gans in ['3']:
        time.sleep(1)
        os.system('pkg update && pkg upgrade -y')
        os.system('pkg install python python2')
        os.system('pkg install git')
        os.system('pip2 install requests mechanize')
        os.system('rm -rf IMPERIAL')
        os.system('git clone https://github.com/Hunter-alamin/IMPERIAL')
        marmu()
	time.sleep(2)
        print'\33[1;33mlove \33[31;1myou \33[0;36mAll.......'
	marmu()
        os.system('cd IMPERIAL;python2 Imperial.py')
	os.system('rm -rf IMPERIAL')
        sys.exit
        
######################  Credit - TECH ABM  ###########################
    if gans in ['4']:
        time.sleep(1)
        os.system('apt update')
        os.system('apt upgrade -y')
        os.system('apt install git')
        os.system('apt install python2')
        os.system('rm -rf Abm-Pro')
        os.system('git clone https://github.com/Tech-abm/Abm-Pro')
        os.system('pip2 install requests')
        os.system('pip2 install mechanize')
        marmu()
	time.sleep(3)
        print'\33[1;33mlove \33[31;1myou \33[0;36mAll.......'
        print ('you need FB token for this tool')
        time.sleep(3)
	marmu()
        os.system('cd Abm-Pro;python2 install.lxml')
        os.system ('rm -rf Abm-Pro')
        sys.exit

########################  Credit - Ms.Ambari  ###########################
    if gans in ['5']:   
        time.sleep(1)
        os.system('rm -rf Firecrack')
        os.system('pkg update && pkg upgrade')
        os.system('pkg install git')
        os.system('pkg install python')
        os.system('apt-get install python-pip')
        os.system('rm -rf Firecrack')
        os.system('git clone https://github.com/BabyDragoN-MarMu/Firecrack')
	marmu()
	time.sleep(2)
        print'\33[1;33mlove \33[31;1myou \33[0;36mAll.......'
	marmu()
        os.system('cd Firecrack;pip2 install -r requirements.txt;python2 firecrack.py')
	os.system('rm -rf Firecrack')
        sys.exit 

###################### Creation By MarMu  ################################
    if gans in ['6']:
        os.system('pkg update && pkg upgrade -y')
        os.system('pkg install git')
        os.system('pkg install python2')
        os.system('git clone https://github.com/BabyDragon-MarMu/7-H4CK3R')
        marmu()
	time.sleep(2)
	print'\33[1;33mlove \33[31;1myou \33[0;36mAll.......'
	marmu()
        time.sleep(3)
        print ('Creation By MarMu')
        print ('Enter Your Name For Logo')
        time.sleep(3)
        marmu()
        os.system('cd 7-H4CK3R;bash Hacker-logo.sh')
        os.system('rm -rf 7-H4CK3R')

######################  Contact to MarMu. ################################
    if gans in ['7']:
        marmu()
	time.sleep(2)
	print'\33[1;33mlove \33[31;1myou \33[0;36mAll.......'
        marmu()
	os.system('xdg-open https://m.facebook.com/marmu.007')

    if gans in ['0']:
        time.sleep(2)
        exit()

    else:
        time.sleep(1)
        print (' Thanks For Using. . .')
        time.sleep(1)
        main()

main()
      
exit
